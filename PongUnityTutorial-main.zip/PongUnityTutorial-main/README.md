# PongUnityTutorial
Repo for the Youtube tutorial series about creating Pong in Unity
https://www.youtube.com/playlist?list=PLEl7CIZGv53xhngxJdS_GAaSXpXcN-hSP
